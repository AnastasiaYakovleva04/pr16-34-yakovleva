﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace pr16_4_yakovleva
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private Dictionary<string, long> countries = new Dictionary<string, long>();

        private void openFile_Click(object sender, EventArgs e)
        {
            countries.Clear();
            countriesList.Items.Clear();
            labelList.Text = "Список стран";
            string path = textBoxPath.Text;
            if (File.Exists(path))
            {
                foreach (Control control in this.Controls)
                    control.Visible = true;
                string[] lines = File.ReadAllLines(path);
                foreach (string line in lines)
                {
                    string[] parts = line.Split(new char[] { ' ' }, 2);
                    if (parts.Length == 2)
                    {
                        string countryName = parts[0];
                        string populationString = parts[1];
                        populationString = populationString.Replace(" ", "");
                        if (long.TryParse(populationString, out long population))
                        {
                            countries.Add(countryName, population);
                            countriesList.Items.Add($"{countryName} {parts[1]}");
                        }
                    }
                }
                population.Maximum = countries.Values.Max();
            }
            else
                MessageBox.Show("Файл с таким именем не найден", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void findCountries_Click(object sender, EventArgs e)
        {
            int n =(int)population.Value;
            labelList.Text = $"Список стран с населением более {n}";
            countriesList.Items.Clear();
            var sortedCountries = from country in countries
                                  where country.Value > n
                                  orderby country.Key
                                  select country;
            foreach (var country in sortedCountries)
                countriesList.Items.Add($"{country.Key} {country.Value}");
        }
    }
}
