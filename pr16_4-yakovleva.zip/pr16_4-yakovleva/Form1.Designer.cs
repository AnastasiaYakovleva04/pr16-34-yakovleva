﻿
namespace pr16_4_yakovleva
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.textBoxPath = new System.Windows.Forms.TextBox();
            this.openFile = new System.Windows.Forms.Button();
            this.population = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.countriesList = new System.Windows.Forms.ListBox();
            this.findCountries = new System.Windows.Forms.Button();
            this.labelList = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.population)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(52, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(169, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Введите имя файла:";
            // 
            // textBoxPath
            // 
            this.textBoxPath.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxPath.Location = new System.Drawing.Point(56, 55);
            this.textBoxPath.Name = "textBoxPath";
            this.textBoxPath.Size = new System.Drawing.Size(165, 26);
            this.textBoxPath.TabIndex = 1;
            // 
            // openFile
            // 
            this.openFile.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.openFile.Location = new System.Drawing.Point(56, 88);
            this.openFile.Name = "openFile";
            this.openFile.Size = new System.Drawing.Size(165, 35);
            this.openFile.TabIndex = 2;
            this.openFile.Text = "Открыть файл";
            this.openFile.UseVisualStyleBackColor = true;
            this.openFile.Click += new System.EventHandler(this.openFile_Click);
            // 
            // population
            // 
            this.population.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.population.Location = new System.Drawing.Point(56, 231);
            this.population.Name = "population";
            this.population.Size = new System.Drawing.Size(165, 26);
            this.population.TabIndex = 3;
            this.population.Visible = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(52, 208);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(267, 20);
            this.label2.TabIndex = 4;
            this.label2.Text = "Введите численность населения:";
            this.label2.Visible = false;
            // 
            // countriesList
            // 
            this.countriesList.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.countriesList.FormattingEnabled = true;
            this.countriesList.ItemHeight = 20;
            this.countriesList.Location = new System.Drawing.Point(366, 55);
            this.countriesList.Name = "countriesList";
            this.countriesList.Size = new System.Drawing.Size(323, 364);
            this.countriesList.TabIndex = 5;
            this.countriesList.Visible = false;
            // 
            // findCountries
            // 
            this.findCountries.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.findCountries.Location = new System.Drawing.Point(56, 264);
            this.findCountries.Name = "findCountries";
            this.findCountries.Size = new System.Drawing.Size(165, 36);
            this.findCountries.TabIndex = 6;
            this.findCountries.Text = "Найти";
            this.findCountries.UseVisualStyleBackColor = true;
            this.findCountries.Visible = false;
            this.findCountries.Click += new System.EventHandler(this.findCountries_Click);
            // 
            // labelList
            // 
            this.labelList.AutoSize = true;
            this.labelList.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelList.Location = new System.Drawing.Point(362, 32);
            this.labelList.Name = "labelList";
            this.labelList.Size = new System.Drawing.Size(111, 20);
            this.labelList.TabIndex = 7;
            this.labelList.Text = "Список стран";
            this.labelList.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.labelList);
            this.Controls.Add(this.findCountries);
            this.Controls.Add(this.countriesList);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.population);
            this.Controls.Add(this.openFile);
            this.Controls.Add(this.textBoxPath);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.population)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBoxPath;
        private System.Windows.Forms.Button openFile;
        private System.Windows.Forms.NumericUpDown population;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ListBox countriesList;
        private System.Windows.Forms.Button findCountries;
        private System.Windows.Forms.Label labelList;
    }
}

